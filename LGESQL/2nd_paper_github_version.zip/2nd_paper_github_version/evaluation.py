import os, sys
import json
import sqlite3
import traceback
import argparse
import numpy as np
#from executor import easyquery
# sys.path.append(os.path.dirname(os.path.dirname(__file__)))
import copy

def get_schema_from_json(fpath):
    with open(fpath) as f:
        data = json.load(f)

    schema = {}
    for entry in data:
        table = str(entry['table'].lower())
        cols = [str(col['column_name'].lower()) for col in entry['col_data']]
        schema[table] = cols

    return schema

# Flag to disable value evaluation
DISABLE_VALUE = True
# Flag to disable distinct in select evaluation
DISABLE_DISTINCT = True

CLAUSE_KEYWORDS = ('select', 'from', 'where', 'group', 'order', 'limit', 'intersect', 'union', 'except')
JOIN_KEYWORDS = ('join', 'on', 'as')

WHERE_OPS = ('not', 'between', '=', '>', '<', '>=', '<=', '!=', 'in', 'like', 'is', 'exists')
UNIT_OPS = ('none', '-', '+', "*", '/')
AGG_OPS = ('none', 'max', 'min', 'count', 'sum', 'avg')
TABLE_TYPE = {
    'sql': "sql",
    'table_unit': "table_unit",
}

COND_OPS = ('and', 'or')
SQL_OPS = ('intersect', 'union', 'except')
ORDER_OPS = ('desc', 'asc')


HARDNESS = {
    "component1": ('where', 'group', 'order', 'limit', 'join', 'or', 'like'),
    "component2": ('except', 'union', 'intersect')
}

def condition_has_or(logic_list):
  return 'OR' in logic_list

def condition_has_like(condition_list):
  return ('LIKE' in [item[1] for item in condition_list]) or ('NOT LIKE' in [item[1] for item in condition_list])

def condition_has_sql(condition_list):
  for item in condition_list:
    val1, val2 = item[0], item[2]
    if val1 is not None and type(val1) is dict:
      return True
    if val2 is not None and type(val2) is dict:
      return True
  return False

def val_has_op(val_unit): #checking operator
  return val_unit is list

def has_agg(unit): #from aggregation_list
  return unit != ''

def accuracy(count, total):
  if count == total:
    return 1
  return 0

def recall(count, total):
  if count == total:
    return 1
  return 0


def F1(acc, rec):
  if (acc + rec) == 0:
      return 0
  return (2. * acc * rec) / (acc + rec)

def get_scores(count, pred_total, label_total): 
  if pred_total != label_total:
    return 0,0,0
  elif count == pred_total:
    return 1,1,1
  return 0,0,0

def eval_sel(pred, label):
  pred_sel = copy.deepcopy(pred['getSelect'])
  label_sel = copy.deepcopy(label['getSelect'])
  label_agg = copy.deepcopy(label_sel['aggregation_list'])
  pred_total = len(pred_sel['column_list'])
  label_total = len(label_sel['column_list'])
  cnt = 0
  cnt_wo_agg = 0
  
  for i in range(len(pred_sel['column_list'])):
    if pred_sel['column_list'][i] in label_sel['column_list']:
      index_col_name = label_sel['column_list'].index(pred_sel['column_list'][i])
      if pred_sel['column_table_list'][i] == label_sel['column_table_list'][index_col_name]:
        cnt_wo_agg += 1
        label_sel['column_list'].remove(pred_sel['column_list'][i])
        label_sel['column_table_list'].remove(pred_sel['column_table_list'][i])
        if pred_sel['aggregation_list'][i] == label_agg[index_col_name]:
          cnt += 1
          label_agg.remove(pred_sel['aggregation_list'][i])
  print(cnt_wo_agg)

  print('select',label_total, pred_total, cnt, cnt_wo_agg)
  return label_total, pred_total, cnt, cnt_wo_agg

def eval_where(pred, label): #no aggregation in where clause
  pred_conds = copy.deepcopy(pred['getWhere'])
  label_conds = copy.deepcopy(label['getWhere'])
  pred_total = len(pred_conds['condition_list'])
  label_total = len(label_conds['condition_list'])
  cnt = 0
  cnt_wo_agg = 0

  for i in range(len(pred_conds['condition_list'])):
    if pred_conds['condition_list'][i] in label_conds['condition_list']:
      index_cond = label_conds['condition_list'].index(pred_conds['condition_list'][i])
      if pred_conds['condition_table_list'][i] == label_conds['condition_table_list'][index_cond]:
        cnt_wo_agg += 1
        label_conds['condition_list'].remove(pred_conds['condition_list'][i])
        label_conds['condition_table_list'].remove(pred_conds['condition_table_list'][i])
  cnt = cnt_wo_agg

  print('where',label_total, pred_total, cnt, cnt_wo_agg)
  return label_total, pred_total, cnt, cnt_wo_agg

def eval_group(pred, label):
  pred_cols = copy.deepcopy(pred['getGroupby'])
  label_cols = copy.deepcopy(label['getGroupby'])
  pred_total = len(pred_cols['column_list'])
  label_total = len(label_cols['column_list'])
  cnt = 0

  for i in range(len(pred_cols['column_list'])):
    if pred_cols['column_list'][i] in label_cols['column_list']:
      index_col_name = label_cols['column_list'].index(pred_cols['column_list'][i])
      if pred_cols['column_table_list'][i] == label_cols['column_table_list'][index_col_name]:
        cnt += 1
        label_cols['column_list'].remove(pred_cols['column_list'][i])
        label_cols['column_table_list'].remove(pred_cols['column_table_list'][i])
  
  print("group", label_total, pred_total, cnt)
  return label_total, pred_total, cnt

def eval_having(pred, label): 
  pred_total = label_total = 0
  cnt = 1
  if len(pred['getGroupby']['condition_list']) > 0:
    pred_total = 1
  if len(label['getGroupby']['condition_list']) > 0:
    label_total = 1
  pred_conds = copy.deepcopy(pred['getGroupby'])
  label_conds = copy.deepcopy(label['getGroupby'])
  label_agg = copy.deepcopy(label_conds['aggregation_list'])

  if pred_total == label_total == 1:
    for i in range(len(pred_conds['condition_list'])):
      if pred_conds['condition_list'][i] in label_conds['condition_list']:
        index_cond = label_conds['condition_list'].index(pred_conds['condition_list'][i])
        if pred_conds['condition_table_list'][i] == label_conds['condition_table_list'][index_cond]:
          label_conds['condition_list'].remove(pred_conds['condition_list'][i])
          label_conds['condition_table_list'].remove(pred_conds['condition_table_list'][i])
          if pred_conds['aggregation_list'][i] == label_agg[index_cond]:
            label_agg.remove(pred_conds['aggregation_list'][i])
          else:
            cnt = 0
        else:
          cnt = 0
      else:
        cnt = 0
  else:
    cnt = 0
  
  print('having',label_total, pred_total, cnt)
  return label_total, pred_total, cnt

#Starting 2022/10/4
def eval_order(pred, label):
  pred_total = label_total = cnt = 0
  if len(pred['getOrderby']['column_list']) > 0:
      pred_total = 1
  if len(label['getOrderby']['column_list']) > 0:
      label_total = 1
  if len(label['getOrderby']['column_list']) > 0 and pred['getOrderby'] == label['getOrderby']:
      cnt = 1


  pred_cols = copy.deepcopy(pred['getOrderby'])
  label_cols = copy.deepcopy(label['getOrderby'])
  label_agg = copy.deepcopy(label_cols['aggregation_list'])
  label_ascend = copy.deepcopy(label_cols['ascending_list'])
  
  if pred_total == label_total and label_total == 1 and pred_cols['limit'] == label_cols['limit']:
    for i in range(len(pred_cols['column_list'])):
      if pred_cols['column_list'][i] in label_cols['column_list']:
        index_col = label_cols['column_list'].index(pred_cols['column_list'][i])
        if pred_cols['column_table_list'][i] == label_cols['column_table_list'][index_col]:
          label_cols['column_list'].remove(pred_cols['column_list'][i])
          label_cols['column_table_list'].remove(pred_cols['column_table_list'][i])
          if pred_cols['aggregation_list'][i] == label_agg[index_col]:
            label_agg.remove(pred_cols['aggregation_list'][i])
            if pred_cols['ascending_list'][i] == label_ascend[index_col]:
              label_ascend.remove(pred_cols['ascending_list'][i])
            else:
              cnt = 0
          else:
            cnt = 0
        else:
          cnt = 0
      else:
        cnt = 0
  else:
    cnt = 0 
  print('order',label_total, pred_total, cnt)
  return label_total, pred_total, cnt

def eval_and_or(pred, label): #use set is not correct here, consider if we have two ORs...
  pred_ao = pred['getWhere']['logic_list']
  label_ao = label['getWhere']['logic_list']
  pred_ao.sort()
  label_ao.sort()

  if pred_ao == label_ao:
    print('eval_and_or',1,1,1)
    return 1,1,1
  print('eval_and_or',len(pred_ao),len(label_ao),0)
  return len(pred_ao),len(label_ao),0

def get_nestedSQL(python):
  nested = []
  if python['getFrom']['subquery'] != {}:
    nested.append(python['getFrom']['subquery'])
  
  for cond_unit in python['getWhere']['condition_list']:
    if type(cond_unit[0]) is dict:
      nested.append(cond_unit[2])    
    if type(cond_unit[2]) is dict:
      nested.append(cond_unit[2])
  for cond_unit in python['getGroupby']['condition_list']:
    if type(cond_unit[0]) is dict:
      nested.append(cond_unit[2])    
    if type(cond_unit[2]) is dict:
      nested.append(cond_unit[2])

  if python['intersect'] != {}:
      nested.append(python['intersect'])
  if python['except'] != {}:
      nested.append(python['except'])
  if python['union'] != {}:
      nested.append(python['union'])
  
  return nested

#need to wait until we finish refactoring evaluator
def eval_nested(pred, label):
  label_total = 0
  pred_total = 0
  cnt = 0
  if pred != {}:
    pred_total += 1
  if label != {}:
    label_total += 1
  if pred != {} and label != {}:
    cnt += Evaluator().eval_exact_match(pred, label)
  print('eval_nested',label_total, pred_total, cnt)
  return label_total, pred_total, cnt

def eval_IUEN(pred, label):
  lt1, pt1, cnt1 = eval_nested(pred['intersect'], label['intersect'])
  lt2, pt2, cnt2 = eval_nested(pred['except'], label['except'])
  lt3, pt3, cnt3 = eval_nested(pred['union'], label['union'])
  label_total = lt1 + lt2 + lt3
  pred_total = pt1 + pt2 + pt3
  cnt = cnt1 + cnt2 + cnt3
  print('eval_IUEN',label_total, pred_total, cnt)
  return label_total, pred_total, cnt

def get_keywords(python):
  res = set()
  if len(python['getWhere']['condition_list']) > 0:
    res.add('where')
  if len(python['getGroupby']['column_list']) > 0:
    res.add('group')
  if len(python['getGroupby']['condition_list']) > 0:
    res.add('having')
  if len(python['getOrderby']['column_list']) > 0:
    if python['getOrderby']['ascending_list'][0]:
      res.add('asc')
    else:
      res.add('desc')
    res.add('order')
  if python['getOrderby']['limit'] != -1:
    res.add('limit')
  if python['except'] != {}:
    res.add('except')
  if python['union'] != {}:
    res.add('union')
  if python['intersect'] != {}:
    res.add('intersect')

  # or keyword
  ao = python['getWhere']['logic_list'] + python['getGroupby']['logic_list']
  if len([token for token in ao if token == 'or']) > 0:
    res.add('or')
  
  cond_units = python['getWhere']['condition_list'] + python['getGroupby']['condition_list']
  if len([cond_unit for cond_unit in cond_units if cond_unit[1] == 'NOT IN' or cond_unit[1] == 'NOT LIKE']) > 0:
    res.add('not')

  # in keyword
  if len([cond_unit for cond_unit in cond_units if cond_unit[1] == 'IN' or cond_unit[1] == 'NOT IN']) > 0:
    res.add('in')

  # like keyword
  if len([cond_unit for cond_unit in cond_units if cond_unit[1] == 'LIKE' or cond_unit[1] == 'NOT LIKE']) > 0:
    res.add('like')
  
  print('get_keywords',res)
  return res

def eval_keywords(pred, label):
  pred_keywords = get_keywords(pred)
  label_keywords = get_keywords(label)
  pred_total = len(pred_keywords)
  label_total = len(label_keywords)
  cnt = 0

  for k in pred_keywords:
    if k in label_keywords:
      cnt += 1
  
  print('eval_keywords',label_total, pred_total, cnt)
  return label_total, pred_total, cnt

def count_component1(python):
  count = 0
  if len(python['getWhere']['condition_list']) > 0:
    count += 1
  if len(python['getGroupby']['column_list']) > 0:
    count += 1
  if len(python['getOrderby']['column_list']) > 0:
    count += 1
  if python['getOrderby']['limit'] != -1:
    count += 1
  if len(python['getFrom']['table_names']) > 0:  # JOIN
    count += len(python['getFrom']['table_names']) - 1

  ao = python['getWhere']['logic_list'] + python['getGroupby']['logic_list']
  count += len([token for token in ao if token == 'or'])
  
  cond_units = python['getWhere']['condition_list'] + python['getGroupby']['condition_list']
  count += len([cond_unit for cond_unit in cond_units if cond_unit[1] == 'LIKE' or cond_unit[1] == 'NOT LIKE'])
  
  print('count_component1',count)
  return count


def count_component2(python):
  nested = get_nestedSQL(python)

  print('count_component2',len(nested))
  return len(nested)

def count_others(python):
  count = 0
  agg_count = 0
  # number of aggregation
  for x in python['getSelect']['aggregation_list']:
    if x != '':
      agg_count += 1
  
  #there exist no sql with aggregation in where and groupby
  for x in python['getOrderby']['aggregation_list']:
    if x!='':
      agg_count += 1
  
  for x in python['getGroupby']['aggregation_list']:
    if x!='':
      agg_count += 1
  
  if agg_count > 1:
    count += 1

  # number of select columns
  if len(python['getSelect']['column_list']) > 1:
    count += 1

  # number of where conditions
  if len(python['getWhere']['condition_list']) > 1:
    count += 1

  # number of group by clauses
  if len(python['getGroupby']['column_list']) > 1:
    count += 1
  print('count_others',count)
  return count

#should change some part to check new figure questions
class Evaluator:
    """A simple evaluator"""
    def __init__(self):
      self.partial_scores = None

    def eval_hardness(self, python):
      count_comp1_ = count_component1(python)
      count_comp2_ = count_component2(python)
      count_others_ = count_others(python)
      print('hardness',count_comp1_,count_comp2_,count_others_)

      if count_comp1_ <= 1 and count_others_ == 0 and count_comp2_ == 0:
        return "easy"
      elif (count_others_ <= 2 and count_comp1_ <= 1 and count_comp2_ == 0) or \
              (count_comp1_ <= 2 and count_others_ < 2 and count_comp2_ == 0):
        return "medium"
      elif (count_others_ > 2 and count_comp1_ <= 2 and count_comp2_ == 0) or \
              (2 < count_comp1_ <= 3 and count_others_ <= 2 and count_comp2_ == 0) or \
              (count_comp1_ <= 1 and count_others_ == 0 and count_comp2_ <= 1):
        return "hard"
      else:
        return "extra"

    def eval_exact_match(self, pred, label):
      partial_scores = self.eval_partial_match(pred, label)
      print('partial_scores')
      print(partial_scores)
      self.partial_scores = partial_scores
      for _, score in partial_scores.items():
        if score['f1'] != 1:
          return 0
      #need to check tables as well
      if label['getFrom']['subquery'] != {} and pred['getFrom']['subquery'] != {}:
        return self.eval_exact_match(pred['getFrom']['subquery'], label['getFrom']['subquery'])
      elif label['getFrom']['subquery'] == {} and pred['getFrom']['subquery'] == {}:
        label_tables = sorted(label['getFrom']['table_names'])
        pred_tables = sorted(pred['getFrom']['table_names'])
        return label_tables == pred_tables
      else:
        return 0
      
      return 1

    def eval_partial_match(self, pred, label):
      res = {}

      label_total, pred_total, cnt, cnt_wo_agg = eval_sel(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['select'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}
      acc, rec, f1 = get_scores(cnt_wo_agg, pred_total, label_total)
      res['select(no AGG)'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt, cnt_wo_agg = eval_where(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['where'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}
      acc, rec, f1 = get_scores(cnt_wo_agg, pred_total, label_total)
      res['where(no OP)'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt = eval_group(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['group(no Having)'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt = eval_having(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['group'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt = eval_order(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['order'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt = eval_and_or(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['and/or'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt = eval_IUEN(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['IUEN'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      label_total, pred_total, cnt = eval_keywords(pred, label)
      acc, rec, f1 = get_scores(cnt, pred_total, label_total)
      res['keywords'] = {'acc': acc, 'rec': rec, 'f1': f1,'label_total':label_total,'pred_total':pred_total}

      return res

def isValidPythonQuery(python, db_id):
  try:
    final_result = easyquery(python, db_id)
  except Exception:
    print("dataframe error occured ")
    dataframe_error.append("'"+str(i)+"'")
    traceback.print_exc()
    return False
  return True

def print_scores(scores, etype):
  levels = ['easy', 'medium', 'hard', 'extra', 'all']
  partial_types = ['select', 'select(no AGG)', 'where', 'where(no OP)', 'group(no Having)',
                     'group', 'order', 'and/or', 'IUEN', 'keywords']

  print("{:20} {:20} {:20} {:20} {:20} {:20}".format("", *levels))
  counts = [scores[level]['count'] for level in levels]
  print("{:20} {:<20d} {:<20d} {:<20d} {:<20d} {:<20d}".format("count", *counts))

  if etype in ["all", "exec"]:
    print('=====================   EXECUTION ACCURACY     =====================')
    this_scores = [scores[level]['exec'] for level in levels]
    print("{:20} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f}".format("execution", *this_scores))

  if etype in ["all", "match"]:
    print('\n====================== EXACT MATCHING ACCURACY =====================')
    exact_scores = [scores[level]['exact'] for level in levels]
    print("{:20} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f}".format("exact match", *exact_scores))
    print('\n---------------------PARTIAL MATCHING ACCURACY----------------------')
    for type_ in partial_types:
      this_scores = [scores[level]['partial'][type_]['acc'] for level in levels]
      print("{:20} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f}".format(type_, *this_scores))

    print('---------------------- PARTIAL MATCHING RECALL ----------------------')
    for type_ in partial_types:
      this_scores = [scores[level]['partial'][type_]['rec'] for level in levels]
      print("{:20} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f}".format(type_, *this_scores))

    print('---------------------- PARTIAL MATCHING F1 --------------------------')
    for type_ in partial_types:
      this_scores = [scores[level]['partial'][type_]['f1'] for level in levels]
      print("{:20} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f} {:<20.3f}".format(type_, *this_scores))

def rebuild_condition_values(example):
    
    print("example is ", example)
    # handle where conditions 
    if example['getWhere']['condition_list'] != []:
        for condition in example['getWhere']['condition_list']:
            if (isinstance(condition[2], dict)):
                print("you need to build the subquery")
                condition[2] = rebuild_condition_values(condition[2])
            else:
                condition[2] = None
    print("example is 1 ", example)
    # handle having conditions
    if example['getGroupby']['condition_list'] != []:
        for condition in example['getGroupby']['condition_list']:
            if (isinstance(condition[2], dict)):
                print("you need to build the subquery")
            else:
                condition[2] = None
    print("example is 2 ", example)
    # handle distinct 
    if example['getSelect']['distinct'] != []:
        example['getSelect']['distinct'] = False

    
    
    #print("example is 3 ", example)
    # handle all above for intersect, union, except
    if len(example['intersect'])  == 0:
        print("intersect len = 0")
    else: 
        example['intersect'] = rebuild_condition_values(example['intersect'])
        print("example['intersect']", example['intersect'])

    if len(example['union']) == 0:
        print("union len = 0")
    else: 
        example['union'] = rebuild_condition_values(example['union'])
        print("example['union']", example['union'])

    if len(example['except']) == 0:
        print("except len = 0")
    else: 
        example['except'] = rebuild_condition_values(example['except'])

    return example
    #print("example is 4 ", example)

def rebuild_keys(example, tables, db):

    ## build the foreign_primary_tables 
    numberOfTables = 0
    for table in example['getFrom']['table_names']:
        numberOfTables = numberOfTables + 1
    print("numberOfTables", numberOfTables)

    i = 0
    if numberOfTables > 1:
        for table in example['getFrom']['table_names']:
            if i == 0:
                example['getFrom']['foreign_primary_tables'].append([table,table])
            else:
                example['getFrom']['foreign_primary_tables'][i-1][1] = table
                if numberOfTables > i+1:
                    example['getFrom']['foreign_primary_tables'].append([table,table])
            i = i+1

    print("example['getFrom']['foreign_primary_tables']", example['getFrom']['foreign_primary_tables'])
    

    # create arrays of coulmns for each table
    if example['getFrom']['foreign_primary_tables']:
        print("we are ready to fill the foreign_primary_keys")
        for tableArray in example['getFrom']['foreign_primary_tables']:
            print("tableArray", tableArray)
            for table in tables:
               if table['db_id'] == db['db_id']:
                    table_index = 0
                    # replace tableArray from [table_name1, table_name2] to [table_index1, table_index2]
                    for tableName in table['table_names']:
                        if tableName == tableArray[0]:
                            print("tableArray[0]", tableArray[0])
                            tableArray[0] = table_index
                        if tableName == tableArray[1]:
                            print("tableArray[1]", tableArray[1])
                            tableArray[1] = table_index
                        table_index = table_index + 1
                    
                    # filled table1 and table2 with there columns also filled there indexes
                    table1 = []
                    table2 = []
                    table1_Indexes = []   
                    table2_Indexes = []   
                    columnindex = 0
                    for ColumnName in table['column_names_original']:
                        if ColumnName[0] == tableArray[0]:
                            table1.append(ColumnName[1])
                            table1_Indexes.append(columnindex)
                        if ColumnName[0] == tableArray[1]:
                            table2.append(ColumnName[1])
                            table2_Indexes.append(columnindex)
                        columnindex = columnindex + 1
                    print("check the table and indexes")
                    for i in table1:
                        print('table1', " column", i)
                    for i in table1_Indexes:
                        print('table1_Indexes', " column", i)
                    for i in table2:
                        print('table2', " column", i)
                    for i in table2_Indexes:
                        print('table2_Indexes', " column", i)
                    print("done cheking the table and indexes")

                    #use the column indexes to get the foreign_keys
                    One_Forieign_Primary_Keys_Indexes = []
                    One_Forieign_Primary_Keys_tables = []
                    # we make it empty becuase we can re fill it again with tables names instead of indexes
                    example['getFrom']['foreign_primary_tables'] = []
                    
                    is_looping = True
                    for c1 in table1_Indexes:
                        for c2 in table2_Indexes:
                            for twoKeys in table['foreign_keys']:
                                #print('twoKeys[0] ', twoKeys[0], " twoKeys[1]", twoKeys[1])
                                if twoKeys[0] == c1 and twoKeys[1] == c2:
                                    print("found it 1", c1, c2)
                                    One_Forieign_Primary_Keys_Indexes.append(c1)
                                    One_Forieign_Primary_Keys_tables.append(tableArray[0])
                                    One_Forieign_Primary_Keys_Indexes.append(c2)
                                    One_Forieign_Primary_Keys_tables.append(tableArray[1])
                                    is_looping = False
                                    break 
                                elif twoKeys[1] == c1 and twoKeys[0] == c2:
                                    print("found it 2", c1, c2)
                                    One_Forieign_Primary_Keys_Indexes.append(c1)
                                    One_Forieign_Primary_Keys_tables.append(tableArray[0])
                                    One_Forieign_Primary_Keys_Indexes.append(c2)
                                    One_Forieign_Primary_Keys_tables.append(tableArray[1])
                                    is_looping = False
                                    break
                        if not is_looping:
                            print("breaking from the outerloop")
                            break


                    #replace One_Forieign_Primary_Keys_Indexes from indexes to column names
                    i = 0
                    if len(One_Forieign_Primary_Keys_Indexes) > 0:
                        for t1 in table1_Indexes:
                            if t1 == One_Forieign_Primary_Keys_Indexes[0]:
                                print("correct", table1[i], " index ", i)
                                One_Forieign_Primary_Keys_Indexes[0] = table1[i]
                            i = i+1
                        i = 0
                        for t2 in table2_Indexes:
                            if t2 == One_Forieign_Primary_Keys_Indexes[1]:
                                One_Forieign_Primary_Keys_Indexes[1] = table2[i]
                            i = i+1
                        
                        example['getFrom']['foreign_primary_key'].append(One_Forieign_Primary_Keys_Indexes)
                        example['getFrom']['foreign_primary_tables'].append(One_Forieign_Primary_Keys_tables)

    example['getFrom']['foreign_primary_tables'] = []
    ## build the foreign_primary_tables 
    numberOfTables = 0
    for table in example['getFrom']['table_names']:
        numberOfTables = numberOfTables + 1
    print("numberOfTables", numberOfTables)

    i = 0
    if numberOfTables > 1:
        for table in example['getFrom']['table_names']:
            if i == 0:
                example['getFrom']['foreign_primary_tables'].append([table,table])
            else:
                example['getFrom']['foreign_primary_tables'][i-1][1] = table
                if numberOfTables > i+1:
                    example['getFrom']['foreign_primary_tables'].append([table,table])
            i = i+1
    print("example['getFrom']['foreign_primary_key11']", example['getFrom']['foreign_primary_key'])
    return example

def evaluate(predected_array, gold_array, db_array, gold, predict, db_dir, etype, kmaps):
  #with open(file) as f:
  #  resultlist = json.load(f)


      # handling values in the ground truth and the predicted code for example orlando in where condition or value in having condition
  
  #evaluator = Evaluator()
  
  #levels = ['easy', 'medium', 'hard', 'extra', 'all']
  #partial_types = ['select', 'select(no AGG)', 'where', 'where(no OP)', 'group(no Having)',
  #                  'group', 'order', 'and/or', 'IUEN', 'keywords']
  #entries = []
  #scores = {}
  
  #for level in levels:
  #  scores[level] = {'count': 0, 'partial': {}, 'exact': 0.}
  #  scores[level]['exec'] = 0
  #  for type_ in partial_types:
  #    scores[level]['partial'][type_] = {'acc': 0., 'rec': 0., 'f1': 0.,'acc_count':0,'rec_count':0}

  i = 0
  correct_dist = 0
  correct_subkind = 0
  correct_table = 0
  correct_column = 0
  extra_param = 0
  correctANDfalse_dist = 0

  for item in predected_array:
    p_python = item
    print("predict python  ", p_python)
    g_python = gold_array[i]

    print("extra_param before", g_python['extra_param'])
    whereOPS = ['=','>','<','>=','<=','!=']

    ind = 0
    for item in g_python['extra_param']:
      if item:
         if item[1] in whereOPS:
           s = [item[0],item[1]]
           g_python['extra_param'][ind] = s
         else:
          g_python['extra_param'][ind] = []
      else:
        g_python['extra_param'][ind] = []

      ind = ind + 1

    print("extra_param after", g_python['extra_param'])


    print("gold python  ", g_python)
    db = db_array[i]


    if p_python == g_python:
      correct_dist = correct_dist + 1
      correctANDfalse_dist = correctANDfalse_dist + 1
    else:
      correctANDfalse_dist = correctANDfalse_dist + 1

    if p_python['sub_kinds'] == g_python['sub_kinds']:
      correct_subkind = correct_subkind + 1
    if p_python['table'] == g_python['table']:
      correct_table = correct_table + 1
    if p_python['columns'] == g_python['columns']:
      correct_column = correct_column + 1
    if p_python['extra_param'] == g_python['extra_param']:
      extra_param = extra_param + 1

    i = i + 1
  
  print("correct_table  ", correct_table)
  print("correct_columns  ", correct_column)
  print("correct_subkind" , correct_subkind)
  print("correct  ", correct_dist)
  print("correct_extra_param  ", extra_param)
  print("correctANDfalse  ", correctANDfalse_dist)
  scores = correct_dist/correctANDfalse_dist


    #hardness = evaluator.eval_hardness(g_python)
    #scores[hardness]['count'] += 1
    #scores['all']['count'] += 1

    #if etype in ["all", "exec"]:
    #  #need to be modified (maybe we should use old format for gold python json)
    #  exec_score = eval_exec_match(db, p_python, g_python)
    #  if exec_score:
    #    scores[hardness]['exec'] += 1
    
    #if etype in ["all", "match"]:
    #    exact_score = evaluator.eval_exact_match(p_python, g_python)
    #    partial_scores = evaluator.partial_scores
    #    if exact_score == 0:
    #        print("{} pred: {}".format(hardness,p_python))
    #        print("{} gold: {}".format(hardness,g_python))
    #        print("")
    #    scores[hardness]['exact'] += exact_score
    #    scores['all']['exact'] += exact_score
    #    for type_ in partial_types:
    #      if partial_scores[type_]['pred_total'] > 0:
    #        scores[hardness]['partial'][type_]['acc'] += partial_scores[type_]['acc']
    #        scores[hardness]['partial'][type_]['acc_count'] += 1
    #      if partial_scores[type_]['label_total'] > 0:
    #        scores[hardness]['partial'][type_]['rec'] += partial_scores[type_]['rec']
    #        scores[hardness]['partial'][type_]['rec_count'] += 1
    #      scores[hardness]['partial'][type_]['f1'] += partial_scores[type_]['f1']
    #      if partial_scores[type_]['pred_total'] > 0:
    #        scores['all']['partial'][type_]['acc'] += partial_scores[type_]['acc']
    #        scores['all']['partial'][type_]['acc_count'] += 1
    #      if partial_scores[type_]['label_total'] > 0:
    #        scores['all']['partial'][type_]['rec'] += partial_scores[type_]['rec']
    #        scores['all']['partial'][type_]['rec_count'] += 1
    #      scores['all']['partial'][type_]['f1'] += partial_scores[type_]['f1']

    #    entries.append({
    #        'predictPython': p_python,
    #        'goldPython': g_python,
    #        'hardness': hardness,
    #        'exact': exact_score,
    #        'partial': partial_scores
    #    })
    #i = i + 1

  #for level in levels:
  #  if scores[level]['count'] == 0:
  #    continue
  #  if etype in ["all", "exec"]:
  #    scores[level]['exec'] /= scores[level]['count']

  #  if etype in ["all", "match"]:
  #    scores[level]['exact'] /= scores[level]['count']
  #    for type_ in partial_types:
  #      if scores[level]['partial'][type_]['acc_count'] == 0:
  #        scores[level]['partial'][type_]['acc'] = 0
  #      else:
  #        scores[level]['partial'][type_]['acc'] = scores[level]['partial'][type_]['acc'] / \
  #                                                    scores[level]['partial'][type_]['acc_count'] * 1.0
  #      if scores[level]['partial'][type_]['rec_count'] == 0:
  #        scores[level]['partial'][type_]['rec'] = 0
  #     else:
  #        scores[level]['partial'][type_]['rec'] = scores[level]['partial'][type_]['rec'] / \
  #                                                    scores[level]['partial'][type_]['rec_count'] * 1.0
  #      if scores[level]['partial'][type_]['acc'] == 0 and scores[level]['partial'][type_]['rec'] == 0:
  #        scores[level]['partial'][type_]['f1'] = 1
  #      else:
  #        scores[level]['partial'][type_]['f1'] = \
  #            2.0 * scores[level]['partial'][type_]['acc'] * scores[level]['partial'][type_]['rec'] / (
  #            scores[level]['partial'][type_]['rec'] + scores[level]['partial'][type_]['acc'])

  print("Dist ACC", scores)
  return scores

def eval_exec_match(db, pred, gold):
  """
  return 1 if the values between prediction and gold are matching
  in the corresponding index. Currently not support multiple col_unit(pairs).
  """
  try:
    predict_result = easyquery(pred, db)
  except:
    return False
  gold_result = easyquery(gold, db)
  predict_result = dataframe_to_nparray(predict_result)
  gold_result = dataframe_to_nparray(gold_result)
  
  sorted_gold_result = np.sort(gold_result.astype(str).flat)
  sorted_predict_result = np.sort(predict_result.astype(str).flat)
  
  execution_equal = np.array_equal(sorted_gold_result, sorted_predict_result)
  print("execution_equal",execution_equal)
  return execution_equal

def dataframe_to_nparray(result):
  final_result = np.array(result)
  NumberTypes = (int, float)
  if not isinstance(final_result, NumberTypes):
    if final_result.ndim >= 2:
      final_result = [["" if x is np.nan else x for x in l] for l in final_result]
  final_result = np.array(final_result)
  return final_result

##need some time to rebuild foreign/primary key pairs
# Rebuild SQL functions for foreign key evaluation

#we have list for table names directly
def build_valid_col_units(table_units, schema):

  # col_ids = [table_unit[1] for table_unit in table_units if table_unit[0] == TABLE_TYPE['table_unit']]
  # prefixs = [col_id[:-2] for col_id in col_ids]
  
  prefixs = [table_unit for table_unit in table_units]
  valid_col_units= []
  for value in schema.idMap.values():
    if '.' in value and value[:value.index('.')] in prefixs:
      valid_col_units.append(value)
  return valid_col_units

#what is col_unit here? Do we use agg_id?
def rebuild_col_unit_col(valid_col_units, col_unit, kmap):
  if col_unit is None:
    return col_unit

  agg_id, col_id, distinct = col_unit
  if col_id in kmap and col_id in valid_col_units:
    col_id = kmap[col_id]
  if DISABLE_DISTINCT:
    distinct = None
  return agg_id, col_id, distinct

def build_foreign_key_map(entry):
    cols_orig = entry["column_names_original"]
    tables_orig = entry["table_names_original"]

    # rebuild cols corresponding to idmap in Schema
    cols = []
    for col_orig in cols_orig:
      if col_orig[0] >= 0:
        t = tables_orig[col_orig[0]]
        c = col_orig[1]
        cols.append("__" + t.lower() + "." + c.lower() + "__")
      else:
        cols.append("__all__")

    def keyset_in_list(k1, k2, k_list):
      for k_set in k_list:
        if k1 in k_set or k2 in k_set:
          return k_set
      new_k_set = set()
      k_list.append(new_k_set)
      return new_k_set

    foreign_key_list = []
    foreign_keys = entry["foreign_keys"]
    for fkey in foreign_keys:
      key1, key2 = fkey
      key_set = keyset_in_list(key1, key2, foreign_key_list)
      key_set.add(key1)
      key_set.add(key2)

    foreign_key_map = {}
    for key_set in foreign_key_list:
      sorted_list = sorted(list(key_set))
      midx = sorted_list[0]
      for idx in sorted_list:
        foreign_key_map[cols[idx]] = cols[midx]

    return foreign_key_map


def build_foreign_key_map_from_json(table):
  with open(table) as f:
    data = json.load(f)
  tables = {}
  for entry in data:
    tables[entry['db_id']] = build_foreign_key_map(entry)
  return tables

#need to check all the other functions to determine the final main function we need to use
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--result', dest='result', type=str)
    parser.add_argument('--db', dest='db', type=str)
    parser.add_argument('--table', dest='table', type=str)
    parser.add_argument('--etype', dest='etype', type=str)
    args = parser.parse_args()

    result = args.result
    db_dir = args.db
    table = args.table
    etype = args.etype
    
    assert etype in ["all", "exec", "match"], "Unknown evaluation method"
    kmaps = build_foreign_key_map_from_json(table)
    
    """
        foreign key map(dict): str -> str
            map each lowercased column to a pivot column in its cluster set
            normalized column: __all__, __t.lower() + . + c.lower()__
    """
    file = 'test_sample.json'
    evaluate(result, db_dir, 'all', kmaps)