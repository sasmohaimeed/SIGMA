#coding=utf8

from asdl.asdl import ASDLGrammar
from asdl.asdl_ast import RealizedField, AbstractSyntaxTree

class Parser():
    """ Parse a json dict into AbstractSyntaxTree object according to specified grammar rules
    Some common methods are implemented in this parent class.
    """
    def __init__(self, grammar: ASDLGrammar):
        super(Parser, self).__init__()
        self.grammar = grammar

    @classmethod
    def from_grammar(cls, grammar: ASDLGrammar):
        grammar_name = grammar._grammar_name
        if 'v0' in grammar_name:
            # TODO: I should change the name of this file to our JSON parse file name
            from asdl.sql.parser.parser_v0 import ParserV0
            return ParserV0(grammar)
        elif 'v1' in grammar_name:
            # TODO: I should change the name of this file to our JSON parse file name
            from asdl.sql.parser.parser_v1 import ParserV1
            return ParserV1(grammar)
        elif 'v2' in grammar_name:
            # TODO: I should change the name of this file to our JSON parse file name
            from asdl.sql.parser.parser_v2 import ParserV2
            return ParserV2(grammar)
        else:
            raise ValueError('Not recognized grammar name %s' % (grammar_name))

    def parse(self, python_json: dict):
        print('python_json  ',python_json)
        try:
            ast_node = self.parse_python(python_json)
            return ast_node
        except Exception as e:
            print('Something Error happened while parsing:', e)
            error_python = [0,[0],0,[[0]],[[]]]
            ast_node = self.parse_python(error_python)
            return ast_node

    def parse_python(self, python: dict):
        num_of_subkinds = len(python[1])
        print('num_of_subkinds  ',num_of_subkinds)
        python_ctr = ['oneSubkind', 'twoSubkind', 'threeSubkind', 'fourSubkind']
        ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(python_ctr[num_of_subkinds - 1]))
        print('ast_node1  ',ast_node)

        first_kind_entity = {}
        first_kind_entity['main_kind'] = python[0]
        first_kind_entity['sub_kinds'] = python[1][0]
        first_kind_entity['columns'] = python[3][0]
        first_kind_entity['extra_param'] = python[4][0]
        if python_ctr[num_of_subkinds - 1] == 'oneSubkind':
            ast_node.fields[0].add_value(self.parse_python_unit(first_kind_entity))

        elif python_ctr[num_of_subkinds - 1] == 'twoSubkind':
            second_kind_entity = {}
            second_kind_entity['main_kind'] = python[0]
            second_kind_entity['sub_kinds'] = python[1][1]
            second_kind_entity['columns'] = python[3][1]
            second_kind_entity['extra_param'] = python[4][1]
            ast_node.fields[0].add_value(self.parse_python_unit(first_kind_entity))
            ast_node.fields[1].add_value(self.parse_python_unit(second_kind_entity))

        elif python_ctr[num_of_subkinds - 1] == 'threeSubkind':
            second_kind_entity = {}
            second_kind_entity['main_kind'] = python[0]
            second_kind_entity['sub_kinds'] = python[1][1]
            second_kind_entity['columns'] = python[3][1]
            second_kind_entity['extra_param'] = python[4][1]
            third_kind_entity = {}
            third_kind_entity['main_kind'] = python[0]
            third_kind_entity['sub_kinds'] = python[1][2]
            third_kind_entity['columns'] = python[3][2]
            third_kind_entity['extra_param'] = python[4][2]
            ast_node.fields[0].add_value(self.parse_python_unit(first_kind_entity))
            ast_node.fields[1].add_value(self.parse_python_unit(second_kind_entity))
            ast_node.fields[2].add_value(self.parse_python_unit(third_kind_entity))

        elif python_ctr[num_of_subkinds - 1] == 'fourSubkind':
            second_kind_entity = {}
            second_kind_entity['main_kind'] = python[0]
            second_kind_entity['sub_kinds'] = python[1][1]
            second_kind_entity['columns'] = python[3][1]
            second_kind_entity['extra_param'] = python[4][1]
            third_kind_entity = {}
            third_kind_entity['main_kind'] = python[0]
            third_kind_entity['sub_kinds'] = python[1][2]
            third_kind_entity['columns'] = python[3][2]
            third_kind_entity['extra_param'] = python[4][2]
            fourth_kind_entity = {}
            fourth_kind_entity['main_kind'] = python[0]
            fourth_kind_entity['sub_kinds'] = python[1][3]
            fourth_kind_entity['columns'] = python[3][3]
            fourth_kind_entity['extra_param'] = python[4][3]
            ast_node.fields[0].add_value(self.parse_python_unit(first_kind_entity))
            ast_node.fields[1].add_value(self.parse_python_unit(second_kind_entity))
            ast_node.fields[2].add_value(self.parse_python_unit(third_kind_entity))
            ast_node.fields[2].add_value(self.parse_python_unit(fourth_kind_entity))

        # handle the table

        table = python[2]
        ast_node.fields[num_of_subkinds].add_value(table)

        return ast_node


    def parse_python_unit(self, python: dict):
        python_ctr = ['Dist', 'Plot', 'Numric', 'Query']
        if python['main_kind'] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(python_ctr[0]))
            print('ast_node2  ',ast_node)
            sub_kind_field = ast_node.fields[0]
            print('sub_kind_field ',sub_kind_field)
            self.parse_distribution_kind(python, sub_kind_field)
        elif python['main_kind'] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(python_ctr[1]))
            print('ast_node2  ',ast_node)
            sub_kind_field = ast_node.fields[0]
            self.parse_plot_kind(python, sub_kind_field)
        elif python['main_kind'] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(python_ctr[2]))
            print('ast_node2  ',ast_node)
            sub_kind_field = ast_node.fields[0]
            self.parse_numric_kind(python, sub_kind_field)
        elif python['main_kind'] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(python_ctr[3]))
            print('ast_node2  ',ast_node)
            sub_kind_field = ast_node.fields[0]
            self.parse_query_kind(python, sub_kind_field)
        
        sub_kind_field = ast_node.fields

        return ast_node

    def parse_distribution_kind(self, python: dict, sub_kind_field: RealizedField):
        raise NotImplementedError

    def parse_plot_kind(self, python: dict, sub_kind_field: RealizedField):
        raise NotImplementedError

    def parse_numric_kind(self, python: dict, sub_kind_field: RealizedField):
        raise NotImplementedError

    def parse_query_kind(self, python: dict, sub_kind_field: RealizedField):
        raise NotImplementedError



