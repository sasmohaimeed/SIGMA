#coding=utf8
from asdl.sql.parser.parser_base import Parser
from asdl.asdl import ASDLGrammar
from asdl.asdl_ast import RealizedField, AbstractSyntaxTree

class ParserV2(Parser):

    def parse_distribution_kind(self, python: dict, sub_kind_field: RealizedField):
        
        dist_ctr = ['normal', 'standard_normal', 'long_tailed', 'binomial', 'poisson','exponential','weibull','chi_square','t','f']
        if python['sub_kinds'] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[0]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[1]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[2]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[3]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[4]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 5:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[5]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 6:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[6]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 7:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[7]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 8:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[8]))
            print("ast_node3 ", ast_node)
        elif python['sub_kinds'] == 9:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(dist_ctr[9]))
            print("ast_node3 ", ast_node)

        col_id = python['columns'][0]
        ast_node.fields[0].add_value(int(col_id))
        print("ast_node5 ", ast_node)

        
        sub_kind_field.add_value(ast_node)

    def parse_plot_kind(self, python: dict, sub_kind_field: RealizedField):

        plot_ctr = ['hist', 'box', 'kde', 'pie', 'bar','scatter','hex','contour','violin']

        if python['sub_kinds'] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[0]))
            print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[1]))
            print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[2]))
            print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[3]))
            print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[4]))
            print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 5:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[5]))
            print("ast_node3 ", ast_node)
            scatter_field = ast_node.fields[0]
            self.parse_scatter_cols(python, scatter_field)

        elif python['sub_kinds'] == 6:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[6]))
            print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 7:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[7]))
            print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 8:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(plot_ctr[8]))
            print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        sub_kind_field.add_value(ast_node)

    def parse_scatter_cols(self, python: dict, scatter_field: RealizedField):
        
        scatter_ctr = ['twoScatter', 'threeScatter', 'fourScatter']
        num_of_cols = len(python['columns'])
        if num_of_cols == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(scatter_ctr[0]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
        elif num_of_cols == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(scatter_ctr[1]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))
        elif num_of_cols == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(scatter_ctr[2]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            col_id3 = python['columns'][3]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))
            ast_node.fields[3].add_value(int(col_id4))

        scatter_field.add_value(ast_node)

    def parse_numric_kind(self, python: dict, sub_kind_field: RealizedField):
        
        numric_ctr = ['mean', 'w_mean', 't_mean', 'mean_ad', 'median','w_median','median_ad','outlier','std','var','range','iqr','frequency_table','mode','standard_error','percentile','corr_matrix','corr_coff','contingency_table','size','ci']
        if python['sub_kinds'] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[0]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[1]))
            #print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[2]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[3]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[4]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 5:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[5]))
            #print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 6:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[6]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 7:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[7]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 8:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[8]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 9:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[9]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 10:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[10]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 11:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[11]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 12:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[12]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 13:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[13]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 14:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[14]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 15:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[15]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 16:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[16]))
            print("ast_node3 ", ast_node)
            corr_matrix_field = ast_node.fields[0]
            self.parse_corr_matrix(python, corr_matrix_field)

        elif python['sub_kinds'] == 17:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[17]))
            #print("ast_node3 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif python['sub_kinds'] == 18:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[18]))
            print("ast_node3 ", ast_node)
            ccontingency_table_field = ast_node.fields[0]
    
            ccontingency_table_ctr = ['twoContingency', 'threeContingency']
            num_of_cols = len(python['columns'])
            if num_of_cols == 2:
                    ast_node1 = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(ccontingency_table_ctr[0]))
                    print("ast_node4 ", ast_node)
                    col_id1 = python['columns'][0]
                    col_id2 = python['columns'][1]
                    ast_node1.fields[0].add_value(int(col_id1))
                    ast_node1.fields[1].add_value(int(col_id2))
            elif num_of_cols == 3:
                    ast_node1 = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(ccontingency_table_ctr[1]))
                    print("ast_node4 ", ast_node)
                    col_id1 = python['columns'][0]
                    col_id2 = python['columns'][1]
                    col_id3 = python['columns'][2]
                    ast_node1.fields[0].add_value(int(col_id1))
                    ast_node1.fields[1].add_value(int(col_id2))
                    ast_node1.fields[2].add_value(int(col_id3))

            ccontingency_table_field.add_value(ast_node1)

            #self.parse_contingency_table(python, ccontingency_table_field)

        elif python['sub_kinds'] == 19:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[19]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))

        elif python['sub_kinds'] == 20:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(numric_ctr[20]))
            #print("ast_node3 ", ast_node)
            col_id = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id))


        sub_kind_field.add_value(ast_node)



    def parse_corr_matrix(self, python: dict, corr_matrix_field: RealizedField):       
        corr_matrix_ctr = ['twoCorrelation', 'threeCorrelation', 'fourCorrelation']
        num_of_cols = len(python['columns'])
        if num_of_cols == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(corr_matrix_ctr[0]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
        elif num_of_cols == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(corr_matrix_ctr[1]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))
        elif num_of_cols == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(corr_matrix_ctr[2]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            col_id3 = python['columns'][3]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))
            ast_node.fields[3].add_value(int(col_id4))
        corr_matrix_field.add_value(ast_node)

    def parse_contingency_table(self, python: dict, ccontingency_table_field: RealizedField):       
        ccontingency_table_ctr = ['twoContingency', 'threeContingency']
        num_of_cols = len(python['columns'])
        if num_of_cols == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(ccontingency_table_ctr[0]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
        elif num_of_cols == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(ccontingency_table_ctr[1]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))


    def parse_query_kind(self, python: dict, sub_kind_field: RealizedField):
        
        query_ctr = ['select', 'where', 'orderby', 'groupby']
        if python['sub_kinds'] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(query_ctr[0]))
            print("ast_node3 ", ast_node)
            select_field = ast_node.fields[0]
            self.parse_select(python, select_field)

        elif python['sub_kinds'] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(query_ctr[1]))
            print("ast_node3 ", ast_node)
            where_field = ast_node.fields[0]
            self.parse_where(python, where_field)

        elif python['sub_kinds'] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(query_ctr[2]))
            print("ast_node3 ", ast_node)
            orderby_field = ast_node.fields[0]
            self.parse_orderby(python, orderby_field)

        elif python['sub_kinds'] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(query_ctr[3]))
            print("ast_node3 ", ast_node)
            groupby_field = ast_node.fields[0]
            self.parse_groupby(python, groupby_field)

        sub_kind_field.add_value(ast_node)

    def parse_select(self, python: dict, select_field: RealizedField):
        
        select_ctr = ['oneSelect', 'twoSelect','threeSelect','fourSelect']
        num_of_cols = len(python['columns'])
        print('num_of_cols ' , num_of_cols)
        print('python ' , python)

        if num_of_cols == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(select_ctr[0]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            ast_node.fields[0].add_value(int(col_id1))
            print('ast_node.fields[0]  ', ast_node.fields[0])

        elif num_of_cols == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(select_ctr[1]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))

        elif num_of_cols == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(select_ctr[2]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))

        elif num_of_cols == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(select_ctr[3]))
            print("ast_node4 ", ast_node)
            col_id1 = python['columns'][0]
            col_id2 = python['columns'][1]
            col_id3 = python['columns'][2]
            col_id4 = python['columns'][3]
            ast_node.fields[0].add_value(int(col_id1))
            ast_node.fields[1].add_value(int(col_id2))
            ast_node.fields[2].add_value(int(col_id3))
            ast_node.fields[3].add_value(int(col_id4))

        select_field.add_value(ast_node)

    def parse_where(self, python: dict, where_field: RealizedField):
        
        where_ctr = ['Eq', 'Gt','Lt','Ge','Le','Neq']

        if python['extra_param'][1] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(where_ctr[0]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(where_ctr[1]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(where_ctr[2]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(where_ctr[3]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 4:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(where_ctr[4]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 5:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(where_ctr[5]))
            print("ast_node3 ", ast_node)


        col_id1 = python['columns'][0]
        ast_node.fields[0].add_value(int(col_id1))
        where_field.add_value(ast_node)

    def parse_orderby(self, python: dict, orderby_field: RealizedField):
        
        orderby_ctr = ['asc', 'desc']

        if python['extra_param'][2] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(orderby_ctr[0]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][2] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(orderby_ctr[1]))
            print("ast_node3 ", ast_node)

        col_id1 = python['columns'][0]
        ast_node.fields[0].add_value(int(col_id1))
        orderby_field.add_value(ast_node)

    def parse_groupby(self, python: dict, groupby_field: RealizedField):
        
        groupby_ctr = ['min', 'max','count','sum']

        if python['extra_param'][1] == 0:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(groupby_ctr[0]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 1:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(groupby_ctr[1]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 2:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(groupby_ctr[2]))
            print("ast_node3 ", ast_node)
        elif python['extra_param'][1] == 3:
            ast_node = AbstractSyntaxTree(self.grammar.get_prod_by_ctr_name(groupby_ctr[3]))
            print("ast_node3 ", ast_node)


        col_id1 = python['columns'][0]
        ast_node.fields[0].add_value(int(col_id1))
        groupby_field.add_value(ast_node)
