#coding=utf8

from asdl.asdl import ASDLGrammar, ASDLConstructor, ASDLProduction
from asdl.asdl_ast import RealizedField, AbstractSyntaxTree
import sys, os
import traceback

class UnParser():

    def __init__(self, grammar: ASDLGrammar):
        """ ASDLGrammar """
        super(UnParser, self).__init__()
        self.grammar = grammar

    @classmethod
    def from_grammar(cls, grammar: ASDLGrammar):
        grammar_name = grammar._grammar_name
        if 'v0' in grammar_name:
            from asdl.sql.unparser.unparser_v0 import UnParserV0
            return UnParserV0(grammar)
        elif 'v1' in grammar_name:
            from asdl.sql.unparser.unparser_v1 import UnParserV1
            return UnParserV1(grammar)
        elif 'v2' in grammar_name:
            from asdl.sql.unparser.unparser_v2 import UnParserV2
            return UnParserV2(grammar)
        else:
            raise ValueError('Not recognized grammar name %s' % (grammar_name))

    def unparse(self, python_ast: AbstractSyntaxTree, db: dict, *args, **kargs):
        try:
            python = self.unparse_python(python_ast, db, *args, **kargs)
            print("python after unparse_python function", python)
            return python
        except Exception as e:
            python = {}
            python['main_kind'] = 'unknown'
            python['sub_kinds'] = 'unknown'
            python['table'] = 'unknown'
            python['columns'] = 'unknown'
            python['extra_param'] = 'unknown'

            print('Something Error happened while unparsing:', e)
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print("exc_type, fname, line",exc_type, fname, exc_tb.tb_lineno)
            print('Something Error happened while unparsing:', e)
            print("traceback", traceback.format_exc())

            return python

#######################################################################    Python and SQL   ##################################################################################
    def unparse_python(self, sql_ast: AbstractSyntaxTree, db: dict, *args, **kargs):
        prod_name = sql_ast.production.constructor.name
        python= {}
        print("prod_name",prod_name)
        if prod_name == 'oneSubkind':
            fields = self.unparse_mainkind(sql_ast.fields[0], db, *args, **kargs)
            print("fields", fields)
            python['main_kind'] = fields['main_kind']
            python['sub_kinds'] = fields['sub_kinds']

            print("sql_ast.fields[1] ",sql_ast.fields[1])
            print("sql_ast.fields[1].value ",sql_ast.fields[1].value)
            python['table'] = db['table_names_original'][int(sql_ast.fields[1].value)]
            
            python['columns'] = fields['columns']
            python['extra_param'] = fields['extra_param']
            print("python inside unparse_python:", python)
            return python

        elif prod_name == 'twoSubkind':
            fields1 = self.unparse_mainkind(sql_ast.fields[0], db, *args, **kargs)
            fields2 = self.unparse_mainkind(sql_ast.fields[1], db, *args, **kargs)
            python['main_kind'] = fields1['main_kind']
            python['sub_kinds'] = [fields1['sub_kinds'][0],fields2['sub_kinds'][0]]
            python['table'] = db['table_names_original'][int(sql_ast.fields[2].value)]
            python['columns'] = [fields1['columns'][0],fields2['columns'][0]]
            python['extra_param'] = [fields1['extra_param'][0],fields2['extra_param'][0]]
            print("python inside unparse_python:", python)
            return python

        elif prod_name == 'threeSubkind':
            fields1 = self.unparse_mainkind(sql_ast.fields[0], db, *args, **kargs)
            fields2 = self.unparse_mainkind(sql_ast.fields[1], db, *args, **kargs)
            fields3 = self.unparse_mainkind(sql_ast.fields[2], db, *args, **kargs)
            python['main_kind'] = fields1['main_kind']
            python['sub_kinds'] = [fields1['sub_kinds'][0],fields2['sub_kinds'][0],fields3['sub_kinds'][0]]
            python['table'] = db['table_names_original'][int(sql_ast.fields[3].value)]
            python['columns'] = [fields1['columns'][0],fields2['columns'][0],fields3['sub_kinds'][0]]
            python['extra_param'] = [fields1['extra_param'][0],fields2['extra_param'][0],fields3['extra_param'][0]]
            print("python inside unparse_python:", python)
            return python

        elif prod_name == 'fourSubkind':
            fields1 = self.unparse_mainkind(sql_ast.fields[0], db, *args, **kargs)
            fields2 = self.unparse_mainkind(sql_ast.fields[1], db, *args, **kargs)
            fields3 = self.unparse_mainkind(sql_ast.fields[2], db, *args, **kargs)
            fields4 = self.unparse_mainkind(sql_ast.fields[3], db, *args, **kargs)
            python['main_kind'] = fields1['main_kind']
            python['sub_kinds'] = [fields1['sub_kinds'][0],fields2['sub_kinds'][0],fields3['sub_kinds'][0],fields4['sub_kinds'][0]]
            python['table'] = db['table_names_original'][int(sql_ast.fields[4].value)]
            python['columns'] = [fields1['columns'][0],fields2['columns'][0],fields3['sub_kinds'][0],fields4['sub_kinds'][0]]
            python['extra_param'] = [fields1['extra_param'][0],fields2['extra_param'][0],fields3['extra_param'][0],fields4['extra_param'][0]]
            print("python inside unparse_python:", python)
            return python


#######################################################################    Python    ##################################################################################
    
    def unparse_mainkind(self, sql_field: RealizedField, db: dict, *args, **kargs):
        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name
        print("prod_name (unparse_mainkind)", prod_name)
        if prod_name == 'Dist':
            python = self.unparse_Dist(sql_ast.fields[0], db, *args, **kargs)
            python['main_kind'] = 'distribution'
        elif prod_name == 'Plot':
            python = self.unparse_Plot(sql_ast.fields[0], db, *args, **kargs)
            python['main_kind'] = 'plot'
        elif prod_name == 'Numric':
            python = self.unparse_Numric(sql_ast.fields[0], db, *args, **kargs)
            python['main_kind'] = 'numric'
        elif prod_name == 'Query':
            python = self.unparse_Query(sql_ast.fields[0], db, *args, **kargs)
            python['main_kind'] = 'query'

        return python



    def unparse_Dist(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name

        tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]

        if prod_name == 'normal':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['normal']

        elif prod_name == 'standard_normal':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['standard_normal']

        elif prod_name == 'long_tailed':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['long_tailed']

        elif prod_name == 'binomial':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['binomial']

        elif prod_name == 'poisson':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['poisson']

        elif prod_name == 'exponential':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['exponential']

        elif prod_name == 'weibull':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['weibull']

        elif prod_name == 'chi_square':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['chi_square']

        elif prod_name == 't':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['t']

        elif prod_name == 'f':
            python['columns'] = [[]]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['f']

        python['extra_param'] = [[]]

        return python

    def unparse_Plot(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name

        
        if prod_name == 'hist':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['hist']

        elif prod_name == 'box':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['box']

        elif prod_name == 'kde':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['kde']

        elif prod_name == 'pie':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['pie']

        elif prod_name == 'bar':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['bar']

        elif prod_name == 'scatter':
            python = self.unparse_scatter_plot(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['scatter']

        elif prod_name == 'hex':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['hex']

        elif prod_name == 'contour':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['contour']

        elif prod_name == 'violin':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['violin']

        python['extra_param'] = [[]]

        return python

    def unparse_scatter_plot(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        if prod_name == 'twoScatter':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'threeScatter':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        if prod_name == 'fourScatter':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        return python

    def unparse_Numric(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name


        if prod_name == 'mean':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['mean']

        elif prod_name == 'w_mean':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['w_mean']

        elif prod_name == 't_mean':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['t_mean']

        elif prod_name == 'mean_ad':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['mean_ad']

        elif prod_name == 'median':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['median']

        elif prod_name == 'w_median':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['w_median']

        elif prod_name == 'median_ad':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['median_ad']
     
        elif prod_name == 'outlier':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['outlier']

        elif prod_name == 'std':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['std']

        elif prod_name == 'var':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['var']

        elif prod_name == 'range':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['range']

        elif prod_name == 'iqr':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['iqr']

        elif prod_name == 'frequency_table':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['frequency_table']

        elif prod_name == 'mode':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['mode']

        elif prod_name == 'standard_error':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['standard_error']

        elif prod_name == 'percentile':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['percentile']

        elif prod_name == 'corr_matrix':
            python = self.unparse_corr_matrix(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['corr_matrix']

        elif prod_name == 'corr_coff':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
            python['sub_kinds'] = ['corr_coff']

        elif prod_name == 'contingency_table':
            python = self.unparse_contingency_table(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['contingency_table']

        elif prod_name == 'size':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['size']

        elif prod_name == 'ci':
            python['columns'] = [[]]
            tab_id, col_name = db['column_names_original'][int(sql_ast.fields[0].value)]
            python['columns'][0].append(col_name)
            python['sub_kinds'] = ['ci']

        python['extra_param'] = [[]]

        return python

    def unparse_corr_matrix(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        if prod_name == 'twoCorrelation':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'threeCorrelation':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        if prod_name == 'fourCorrelation':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        return python

    def unparse_contingency_table(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        if prod_name == 'twoContingency':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'threeContingency':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        return python


    def unparse_Query(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name


        if prod_name == 'select':
            python = self.unparse_select(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['select']
            python['extra_param'] = [[]]

        elif prod_name == 'where':
            python = self.unparse_where(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['where']

        elif prod_name == 'orderby':
            python = self.unparse_orderby(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['orderby']
            python['extra_param'] = [[]]

        elif prod_name == 'groupby':
            python = self.unparse_groupby(sql_ast.fields[0], db, *args, **kargs)
            python['sub_kinds'] = ['groupby']
            python['extra_param'] = [[]]       

        return python

    def unparse_select(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        if prod_name == 'oneSelect':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'twoSelect':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'threeSelect':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'fourSelect':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        return python

    def unparse_where(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        python['columns'] = [[]]
        python['extra_param'] = [[]]

        if prod_name == 'Eq':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
                python['extra_param'][0].append(col_name)
                python['extra_param'][0].append("=")

        elif prod_name == 'Gt':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
                python['extra_param'][0].append(col_name)
                python['extra_param'][0].append(">")

        elif prod_name == 'Lt':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
                python['extra_param'][0].append(col_name)
                python['extra_param'][0].append("<")

        elif prod_name == 'Ge':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
                python['extra_param'][0].append(col_name)
                python['extra_param'][0].append(">=")

        elif prod_name == 'Le':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
                python['extra_param'][0].append(col_name)
                python['extra_param'][0].append("<=")

        elif prod_name == 'Neq':
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)
                python['extra_param'][0].append(col_name)
                python['extra_param'][0].append("!=")

        return python

    def unparse_orderby(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        if prod_name == 'asc':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'desc':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        return python

    def unparse_groupby(self, sql_field: RealizedField, db: dict, *args, **kargs):

        python = {}
        sql_ast = sql_field.value
        prod_name = sql_ast.production.constructor.name       

        if prod_name == 'min':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'max':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'count':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        elif prod_name == 'sum':
            python['columns'] = [[]]
            for col in sql_ast.fields:
                tab_id, col_name = db['column_names_original'][int(col.value)]
                python['columns'][0].append(col_name)

        return python
